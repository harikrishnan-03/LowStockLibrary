# Inventory Low Stock Checker

A Python library to fetch low stock items from an RDS database.

## Installation
```bash
pip install InventoryLowStockLibrary
